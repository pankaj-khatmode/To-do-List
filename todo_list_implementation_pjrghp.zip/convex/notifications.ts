"use node";
import { internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import { v } from "convex/values";
import { Resend } from "resend";
import { formatDistance } from "date-fns";

const resend = new Resend(process.env.CONVEX_RESEND_API_KEY);

export const sendDueReminder = internalAction({
  args: {
    todoId: v.id("todos"),
    userEmail: v.string(),
    todoText: v.string(),
    dueDate: v.number(),
  },
  handler: async (ctx, args) => {
    const { todoId, userEmail, todoText, dueDate } = args;
    const timeUntilDue = formatDistance(dueDate, Date.now(), { addSuffix: true });

    const { data, error } = await resend.emails.send({
      from: "Todo Reminders <notifications@todos.example.com>",
      to: userEmail,
      subject: `⚠️ High Priority Task Due ${timeUntilDue}`,
      html: `
        <div>
          <h2>Task Reminder</h2>
          <p>Your high priority task "${todoText}" is due ${timeUntilDue}.</p>
          <p>Don't forget to complete it!</p>
        </div>
      `,
    });

    if (error) {
      throw new Error("Failed to send email: " + JSON.stringify(error));
    }
    return data;
  },
});
