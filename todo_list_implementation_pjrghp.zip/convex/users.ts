import { internalQuery } from "./_generated/server";
import { v } from "convex/values";

export const getUser = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.userId);
  },
});
