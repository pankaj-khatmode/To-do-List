import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";
import { internalQuery, internalAction } from "./_generated/server";

export const checkUpcomingTasks = internalQuery({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const oneHourFromNow = now + 60 * 60 * 1000;

    // Get all high priority tasks due in the next hour
    const upcomingTasks = await ctx.db
      .query("todos")
      .filter((q) => 
        q.and(
          q.eq(q.field("priority"), "High"),
          q.gt(q.field("dueDate"), now),
          q.lt(q.field("dueDate"), oneHourFromNow),
          q.eq(q.field("completed"), false)
        )
      )
      .collect();

    return upcomingTasks;
  },
});

export const processReminders = internalAction({
  args: {},
  handler: async (ctx) => {
    const tasks = await ctx.runQuery(internal.crons.checkUpcomingTasks);
    
    for (const task of tasks) {
      if (!task.dueDate) continue;
      
      const user = await ctx.runQuery(internal.users.getUser, { userId: task.userId });
      if (!user?.email) continue;

      await ctx.runAction(internal.notifications.sendDueReminder, {
        todoId: task._id,
        userEmail: user.email,
        todoText: task.text,
        dueDate: task.dueDate,
      });
    }
  },
});

const crons = cronJobs();
// Check for upcoming tasks every 15 minutes
crons.interval("check-upcoming-tasks", { minutes: 15 }, internal.crons.processReminders);

export default crons;
