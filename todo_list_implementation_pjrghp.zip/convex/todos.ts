import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    sortBy: v.optional(v.string()),
    filterDueDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    
    let todos = await ctx.db
      .query("todos")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("parentId"), undefined))
      .collect();

    // Apply due date filter
    if (args.filterDueDate === "today") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      todos = todos.filter(todo => {
        if (!todo.dueDate) return false;
        const dueDate = new Date(todo.dueDate);
        return dueDate >= today && dueDate < tomorrow;
      });
    }

    // Apply sorting
    if (args.sortBy === "dueDate") {
      todos.sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate - b.dueDate;
      });
    } else if (args.sortBy === "priority") {
      const priorityOrder: Record<string, number> = { High: 0, Medium: 1, Low: 2 };
      todos.sort((a, b) => {
        const aOrder = a.priority && a.priority in priorityOrder ? priorityOrder[a.priority] : 3;
        const bOrder = b.priority && b.priority in priorityOrder ? priorityOrder[b.priority] : 3;
        return aOrder - bOrder;
      });
    }

    const enrichedTodos = await Promise.all(
      todos.map(async (todo) => {
        const subtasks = await ctx.db
          .query("todos")
          .withIndex("by_parent", (q) => q.eq("parentId", todo._id))
          .collect();
        return { ...todo, subtasks };
      })
    );
    
    return enrichedTodos;
  },
});

export const create = mutation({
  args: {
    text: v.string(),
    description: v.optional(v.string()),
    dueDate: v.optional(v.number()),
    priority: v.string(),
    labels: v.array(v.string()),
    parentId: v.optional(v.id("todos")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    await ctx.db.insert("todos", {
      ...args,
      completed: false,
      status: "TODO",
      userId,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("todos"),
    text: v.optional(v.string()),
    description: v.optional(v.string()),
    completed: v.optional(v.boolean()),
    dueDate: v.optional(v.number()),
    priority: v.optional(v.string()),
    status: v.optional(v.string()),
    labels: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    const { id, ...updates } = args;
    const todo = await ctx.db.get(id);
    if (!todo || todo.userId !== userId) throw new Error("Not found");
    
    await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("todos") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    const todo = await ctx.db.get(args.id);
    if (!todo || todo.userId !== userId) throw new Error("Not found");
    
    // Delete subtasks first
    const subtasks = await ctx.db
      .query("todos")
      .withIndex("by_parent", (q) => q.eq("parentId", args.id))
      .collect();
    
    for (const subtask of subtasks) {
      await ctx.db.delete(subtask._id);
    }
    
    await ctx.db.delete(args.id);
  },
});
