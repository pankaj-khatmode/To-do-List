import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster, toast } from "sonner";
import { useState } from "react";

const priorities = ["Low", "Medium", "High"] as const;
type Priority = typeof priorities[number];

const statuses = ["TODO", "IN_PROGRESS", "DONE"] as const;
type Status = typeof statuses[number];

const defaultLabels = ["Personal", "Work", "Shopping", "Health"];

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Enhanced Todo List</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-4xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const [sortBy, setSortBy] = useState<string>("");
  const [filterDueDate, setFilterDueDate] = useState<string>("");
  const todos = useQuery(api.todos.list, { sortBy, filterDueDate }) ?? [];
  const [isAdding, setIsAdding] = useState(false);
  const [newTodo, setNewTodo] = useState({
    text: "",
    description: "",
    dueDate: "",
    priority: "Medium" as Priority,
    labels: [] as string[],
  });
  
  const create = useMutation(api.todos.create);
  const update = useMutation(api.todos.update);
  const remove = useMutation(api.todos.remove);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTodo.text.trim()) return;
    
    try {
      await create({
        text: newTodo.text,
        description: newTodo.description || undefined,
        dueDate: newTodo.dueDate ? new Date(newTodo.dueDate).getTime() : undefined,
        priority: newTodo.priority,
        labels: newTodo.labels,
      });
      setNewTodo({
        text: "",
        description: "",
        dueDate: "",
        priority: "Medium",
        labels: [],
      });
      setIsAdding(false);
      toast.success("Todo added!");
    } catch (error) {
      toast.error("Failed to add todo");
    }
  };

  const getPriorityColor = (priority: string | undefined) => {
    switch (priority) {
      case "High": return "text-red-600";
      case "Medium": return "text-yellow-600";
      case "Low": return "text-green-600";
      default: return "text-gray-600";
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Your Todos</h1>
        <Authenticated>
          <p className="text-xl text-slate-600">
            Welcome back, {loggedInUser?.email ?? "friend"}!
          </p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to manage your todos</p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>

      <Authenticated>
        <div className="flex justify-between items-center">
          <div className="flex gap-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="rounded-md border-gray-300 text-sm"
            >
              <option value="">Sort by...</option>
              <option value="dueDate">Due Date</option>
              <option value="priority">Priority</option>
            </select>
            <select
              value={filterDueDate}
              onChange={(e) => setFilterDueDate(e.target.value)}
              className="rounded-md border-gray-300 text-sm"
            >
              <option value="">All Tasks</option>
              <option value="today">Due Today</option>
            </select>
          </div>
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600"
          >
            {isAdding ? "Cancel" : "Add Todo"}
          </button>
        </div>

        {isAdding && (
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg border shadow-sm space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Title</label>
              <input
                type="text"
                value={newTodo.text}
                onChange={(e) => setNewTodo({ ...newTodo, text: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="What needs to be done?"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <textarea
                value={newTodo.description}
                onChange={(e) => setNewTodo({ ...newTodo, description: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                rows={3}
                placeholder="Add details..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Due Date</label>
                <input
                  type="date"
                  value={newTodo.dueDate}
                  onChange={(e) => setNewTodo({ ...newTodo, dueDate: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Priority</label>
                <select
                  value={newTodo.priority}
                  onChange={(e) => setNewTodo({ ...newTodo, priority: e.target.value as Priority })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  {priorities.map(priority => (
                    <option key={priority} value={priority}>{priority}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Labels</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {defaultLabels.map(label => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => {
                      const labels = newTodo.labels.includes(label)
                        ? newTodo.labels.filter(l => l !== label)
                        : [...newTodo.labels, label];
                      setNewTodo({ ...newTodo, labels });
                    }}
                    className={`px-3 py-1 rounded-full text-sm ${
                      newTodo.labels.includes(label)
                        ? "bg-indigo-500 text-white"
                        : "bg-gray-200 text-gray-700"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!newTodo.text.trim()}
                className="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 disabled:opacity-50"
              >
                Add Todo
              </button>
            </div>
          </form>
        )}

        <div className="space-y-4">
          {todos.map((todo) => (
            <div key={todo._id} className="bg-white p-4 rounded-lg border shadow-sm">
              <div className="flex items-center gap-4">
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => update({ id: todo._id, completed: !todo.completed })}
                  className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className={`font-medium ${todo.completed ? 'line-through text-gray-500' : ''}`}>
                      {todo.text}
                    </h3>
                    <span className={`text-sm font-medium ${getPriorityColor(todo.priority)}`}>
                      {todo.priority}
                    </span>
                  </div>
                  
                  {todo.description && (
                    <p className="text-gray-600 text-sm mt-1">{todo.description}</p>
                  )}
                  
                  {todo.labels && todo.labels.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {todo.labels.map(label => (
                        <span
                          key={label}
                          className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs"
                        >
                          {label}
                        </span>
                      ))}
                    </div>
                  )}
                  
                  {todo.dueDate && (
                    <p className="text-gray-500 text-sm mt-2">
                      Due: {new Date(todo.dueDate).toLocaleDateString()}
                    </p>
                  )}
                </div>

                <select
                  value={todo.status ?? "TODO"}
                  onChange={(e) => update({ id: todo._id, status: e.target.value as Status })}
                  className="rounded-md border-gray-300 text-sm"
                >
                  {statuses.map(status => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>

                <button
                  onClick={() => remove({ id: todo._id })}
                  className="text-red-500 hover:text-red-700"
                >
                  Delete
                </button>
              </div>

              {todo.subtasks && todo.subtasks.length > 0 && (
                <div className="ml-8 mt-4 space-y-2">
                  {todo.subtasks.map(subtask => (
                    <div key={subtask._id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={subtask.completed}
                        onChange={() => update({ id: subtask._id, completed: !subtask.completed })}
                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className={subtask.completed ? 'line-through text-gray-500' : ''}>
                        {subtask.text}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </Authenticated>
    </div>
  );
}
